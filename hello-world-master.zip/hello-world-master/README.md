# hello-world
this is sample code in PHP server side script language
